n=10
h=(1/(n+1))
A=zeros(n,n)
F =[(1/2)-(h/6);zeros(n-1,1)]
Aki=[-1/2 1/2;-1/2 1/2]+(h/6)*[2 1;1 2]
A(1,1)=A(1,1)+Aki(2,2)
for i=2:10
    A(i-1,i-1)=A(i-1,i-1)+Aki(1,1)
    A(i-1,i)=A(i-1,i)+Aki(1,2)
    A(i,i-1)=A(i,i-1)+Aki(2,1)
    A(i,i)=A(i,i)+Aki(2,2)
end
X=h:h:1-h
U=linsolve(A,F)
plot(X,U,'LineWidth',2)
xlabel('x')
ylabel('U')
