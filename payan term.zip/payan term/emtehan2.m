
for k=2:6
    h = 1/2^k;
    n = (1/h)-1;
    
    A=zeros(n,n)
    F =[(1/2)-(h/6);zeros(n-1,1)]
    Aki=[-1/2 1/2;-1/2 1/2]+(h/6)*[2 1;1 2]
    A(1,1)=A(1,1)+Aki(2,2)
    
        for i=2:n
        A(i-1,i-1)=A(i-1,i-1)+Aki(1,1)
        A(i-1,i)=A(i-1,i)+Aki(1,2)
        A(i,i-1)=A(i,i-1)+Aki(2,1)
        A(i,i)=A(i,i)+Aki(2,2)
        end
        
    x = (h:h:1-h)';
    U=linsolve(A,F)
    E(k) = log(max(exp(-x) - U))
    R(k)=(E(k)-E(k-1))*1/log(0.5)
end

plot(R,'LineWidth',2)



