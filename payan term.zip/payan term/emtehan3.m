
%kamel nist ....
N1=1- 3*(x/h)^2 +2*(x/h)^3 
N3=3*(x/h)^2-2*(x/h)^3
N2=x*(1-x/h)^2
N4=x^2/h*(x/h-1)
N=[N1 N2 N3 N4]
dN=diff(N,x)
k1= int(N.'*dN,x,0,h)*60
k2= int(N.'*dN,x,0,h)*420/h
ke=k1+k2
n=10

for i=2:n
    Dof=[2*i-3 2*i-2 2*i-1 2*i]
    A(Dof,Dof)=A(Dof,Dof)+ke
end
