%4.3.a
V1 =1;
V2 =0.1;
V3 =0.01;
U0 = 1; Un1 = exp(1);
n=50;
h = 1/(n+1);
x = (h:h:1-h)';
plot( );
hold on
plot((exp(x/V2)-1)*(1/(exp(1/V2)-1)));
plot((exp(x/V3)-1)*(1/(exp(1/V3)-1)));
