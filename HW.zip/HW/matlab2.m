%4.2.b
clear all
V = 0.1; B = 1; Y = 1;
U0 = 1; Un1 = exp(1);
k = 1:12;

for i= 2:11;
    
h = 1/2^k(i);
n = (1/h)-1;
x = (h:h:1-h)';
F = -V*exp(x) + B*exp(x) + Y*exp(x);

D = (1/(2*h))*(diag(zeros(1,n)) + diag(ones(1,n-1),1) + diag(-ones(1,n-1),-1));
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
meghdarmarzi1 = [V*U0/(h*h); zeros(n-2,1); V*Un1/(h*h)];
meghdarmarzi2 = [B*U0/(2*h); zeros(n-2,1); -B*Un1/(2*h)];
F = F + meghdarmarzi1 + meghdarmarzi2;

moadele = V*L + B*D + Y*eye(n);
U = linsolve(moadele, F);

E(i) = log(max(exp(x) - U))
R(i)=(E(i)-E(i-1))*1/log(0.5)
end
plot(R)
