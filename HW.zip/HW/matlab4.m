%4.3.b.center
V = 1;
U0 = 0; Un1 = 1;
n=50;
h = 1/(n+1);
F = zeros(n);F=F(1,:)';
D = (1/(2*h))*(diag(zeros(1,n)) + diag(ones(1,n-1),1) + diag(-ones(1,n-1),-1));
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
meghdarmarzi1 = [V*U0/(h*h); zeros(n-2,1); V*Un1/(h*h)];
meghdarmarzi2 = [U0/(2*h); zeros(n-2,1); Un1/(2*h)];
F = F + meghdarmarzi1 + meghdarmarzi2;

moadele = V*L + D
U = linsolve(moadele, F);
figure(1);
plot(U-(exp(x/V)-1)*(1/(exp(1/V)-1)));

