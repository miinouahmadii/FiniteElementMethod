%4.3.c.upwind
V1= 0.01;
V2= 0.001;
V2= 0.0001;
U0 = 1; Un1 = 1;
n=50;
h =1;
F = zeros(n);F=F(1,:)';
D = (1/(h))*(diag(ones(1,n))+ diag(-ones(1,n-1),-1));
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
meghdarmarziV1 = [V1*U0/(h*h); zeros(n-2,1); V1*Un1/(h*h)];
meghdarmarziV2 = [V2*U0/(h*h); zeros(n-2,1); V2*Un1/(h*h)];
meghdarmarziV3 = [V3*U0/(h*h); zeros(n-2,1); V3*Un1/(h*h)];
meghdarmarzi2 = [U0/(2*h); zeros(n-2,1); -Un1/(2*h)];
F1 = F + meghdarmarziV1 + meghdarmarzi2;
F2 = F + meghdarmarziV2 + meghdarmarzi2;
F3 = F + meghdarmarziV3 + meghdarmarzi2;

moadele1 = V1*L + D;
moadele2 = V2*L + D;
moadele3 = V3*L + D;

U1 = linsolve(moadele1, F1);
U2 = linsolve(moadele2, F2);
U3 = linsolve(moadele3, F3);
figure(1);
plot(U1);
hold on
plot(U2);
plot(U3);