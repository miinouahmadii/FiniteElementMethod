%4.2.a
V = 0.1; B = 1; Y = 1;
U0 = 1; Un1 = exp(1);
n=50;
h = 1/(n+1);
x = (h:h:1-h)';
F = -V*exp(x) + B*exp(x) + Y*exp(x);


D = (1/(2*h))*(diag(zeros(1,n)) + diag(ones(1,n-1),1) + diag(-ones(1,n-1),-1));
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
meghdarmarzi1 = [V*U0/(h*h); zeros(n-2,1); V*Un1/(h*h)];
meghdarmarzi2 = [B*U0/(2*h); zeros(n-2,1); -B*Un1/(2*h)];
F = F + meghdarmarzi1 + meghdarmarzi2;

moadele = V*L + B*D + Y*eye(n)
U = linsolve(moadele, F);

figure(1);
plot(U);


figure(2);
plot(exp(x));

figure(3)
plot(exp(x)- U)
norm_e = max(exp(x) - U)

