
[Uh]=nonFEm()
subplot(1,2,1)
plot (Uh,'LineWidth',2)
xlabel('T')
ylabel('U')
title('nonFEM')

[U, d]=FEm()
subplot(1,2,2)
plot (d,U,'LineWidth',2)
xlabel('d')
ylabel('U')
title('FEM')
