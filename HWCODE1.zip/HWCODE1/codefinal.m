clear all
close all
clc

disc=input('discertization type(center=C,upwind=U  :   ', 's')
BC0=input(' newman=N/dirichle=D   ', 's')
BC1=input(' newman=N/dirichle=D   ', 's')
V0=input(' BC0= :   ')
V1=input(' BC1= :   ')


if BC0=='N' 
    if BC1=='N'
        if disc=='C'
            [moadele,F]=CNN(disc,BC0,BC1,V0,V1)
        else 
            [moadele,F]=UNN(disc,BC0,BC1,V0,V1)
        end
    else
        if disc=='C'
             [moadele,F]=CDN(disc,BC0,BC1,V0,V1)
        else
            [moadele,F]=UDN(disc,BC0,BC1,V0,V1)
        end
    end
else
   if BC1=='N'
       if disc=='C'
           [moadele,F]=CND(disc,BC0,BC1,V0,V1)
       else
           [moadele,F]=UND(disc,BC0,BC1,V0,V1)
       end
   else
        if disc=='C'
            [moadele,F]=CDD(disc,BC0,BC1,V0,V1)
        else
            [moadele,F]=UDD(disc,BC0,BC1,V0,V1)
        end
   end
end


U = linsolve(moadele, F);
figure(1);
plot(U,'LineWidth',2);
xlable('x')
ylable('finite silution')
