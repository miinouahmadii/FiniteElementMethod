function[moadele , F]=CDD(disc,BC0,BC1,V0,V1)
n=6;
h = 1/(n+1);
x = (h:h:1-h)';
F = exp(x);
U0=V0;
U1=V1;

L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);

D = (1/(2*h))*(diag(zeros(1,n)) + diag(ones(1,n-1),1) + diag(-ones(1,n-1),-1));

meghdarmarzi1 = [U0/(h*h); zeros(n-2,1); U1/(h*h)];
meghdarmarzi2 = [2*U0/(2*h);zeros(n-2,1);-2*U1/2*h];

F = F + meghdarmarzi1+meghdarmarzi2;

moadele = L+2*D+eye(n);           
end
