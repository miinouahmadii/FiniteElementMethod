function[moadele , F]=CDN(disc,BC0,BC1,V0,V1)
n=6;
h = 1/(n+2);
x = (h:h:1-h)';
F = exp(x)
U0=V0;
Q1=V1;

Dn= [zeros(1,n-3) -1 0 1 ];
D = (1/(2*h))*(diag(zeros(1,n)) + diag(ones(1,n-1),1) + diag(-ones(1,n-1),-1));
DF=vertcat(D,Dn);

Ln=zeros(1,n);
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
LF=vertcat(L,Ln);

I=eye(n);
In=zeros(1,n);
IF=vertcat(I,In);

meghdarmarzi1 = [U0/(h*h); zeros(n,1)]
meghdarmarzi2 = [(U0*2)/(h*2);zeros(n-1,1);Q1]

F = F + meghdarmarzi1 + meghdarmarzi2

moadele = LF+2*DF+IF;       
end
