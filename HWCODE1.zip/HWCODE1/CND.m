function[moadele , F]=CND(disc,BC0,BC1,V0,V1)
n=6;
h = 1/(n+2);
x = (h:h:1-h)';
F = exp(x)
Q0=V0;
U1=V1;

D1= [-1 0 1 zeros(1,n-3) ];
D =(1/(h))*(diag(ones(1,n))+diag(-ones(1,n-1),-1));
DF=vertcat(D1,D);

L1=zeros(1,n);
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)]);
LF=vertcat(L1,L);

I=eye(n);
I1=zeros(1,n);
IF=vertcat(I1,I);

meghdarmarzi1 = [Q0; zeros(n-1,1);U1/(h*h)]
meghdarmarzi2 = [zeros(n,1);-2*U1/(2*h)]

F = F + meghdarmarzi1 + meghdarmarzi2

moadele = LF+2*DF+IF;
end
