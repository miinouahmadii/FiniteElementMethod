
[U]=ExplicitEuler()
subplot(1,2,1)
plot (U,'LineWidth',2)
xlabel('X')
ylabel('T')
title('ExplicitEuler')

[U]=ImplicitEuler()
subplot(1,2,2)
plot (U,'LineWidth',2)
xlabel('X')
ylabel('T')
title('ImplicitEuler')
