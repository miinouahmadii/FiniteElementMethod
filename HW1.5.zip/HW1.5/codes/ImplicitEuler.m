function[U]=ImplicitEuler()
n=50
dt = 0.00019
h = 1/(n+1)
L = (1/(h*h))*toeplitz([2 -1 zeros(1,n-2)])
U = ones(n,1)
F = zeros(n,1)

    for i=1:10
     U=linsolve(eye(n)+dt*L,U+dt*F)
    end

end
